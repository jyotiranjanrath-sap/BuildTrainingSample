const express = require('express');
const app = express();
const port = process.env.PORT || 3000; 

app.get('/getInfo', (req, res) => {
  let vcapString = process.env.VCAP_SERVICES;
  vcapServices = vcapString ? JSON.parse(vcapString) : vcapServices;
  let credentials, tenantid, instanceid;
  if (vcapServices && vcapServices["destination"] && vcapServices["destination"].length>0) {
    credentials = vcapServices["destination"][0]["credentials"];
  }

  tenantid =  credentials ? credentials["tenantid"] : "";
  instanceid = credentials ? credentials["instanceid"] : "";
  res.send({tenantid, instanceid});
});

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});